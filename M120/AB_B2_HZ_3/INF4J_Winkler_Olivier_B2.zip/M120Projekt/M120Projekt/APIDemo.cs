﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    static class APIDemo
    {
        #region KlasseA
        // Create
        public static void DemoACreate()
        {
            Debug.Print("--- DemoACreate ---");
            // KlasseA

            Data.Auto klasseA1 = new Data.Auto();
            klasseA1.Beschreibung = "Auto 1";
            klasseA1.Preis = 15000;
            klasseA1.Leistung = 300;
            klasseA1.Jahr = 2008;
            klasseA1.Farbe = "Schwarz";
            klasseA1.Zustand = true;
            klasseA1.DatumAttribut = DateTime.Today;
            Int64 klasseA1Id = klasseA1.Erstellen();
            Debug.Print("Autp erstellt mit Id:" + klasseA1Id);
        }
        public static void DemoACreateKurz()
        {
            Data.Auto klasseA2 = new Data.Auto { Beschreibung = "Artikel 2", Preis = 1000, Leistung = 100, Jahr = 2000, Farbe = "Rot", Zustand = true, DatumAttribut = DateTime.Today };
            Int64 klasseA2Id = klasseA2.Erstellen();
            Debug.Print("Artikel erstellt mit Id:" + klasseA2Id);
        }

        // Read
        public static void DemoARead()
        {
            Debug.Print("--- DemoARead ---");
            // Demo liest alle
            foreach (Data.Auto klasseA in Data.Auto.LesenAlle())
            {
                Debug.Print("Artikel Id:" + klasseA.AutoID + " Name:" + klasseA.Beschreibung);
            }
        }
        // Update
        public static void DemoAUpdate()
        {
            Debug.Print("--- DemoAUpdate ---");
            // KlasseA ändert Attribute
            Data.Auto klasseA1 = Data.Auto.LesenID(1);
            klasseA1.Beschreibung = "Artikel 1 nach Update";
            klasseA1.Aktualisieren();
        }
        // Delete
        public static void DemoADelete()
        {
            Debug.Print("--- DemoADelete ---");
            Data.Auto.LesenID(1).Loeschen();
            Debug.Print("Artikel mit Id 1 gelöscht");
        }
        #endregion
    }
}
