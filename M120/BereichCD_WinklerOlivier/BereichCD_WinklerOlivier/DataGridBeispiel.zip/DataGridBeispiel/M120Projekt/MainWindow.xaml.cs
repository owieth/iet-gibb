﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M120Projekt
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; }

        public static long AUTOID;

        Auto auto = new Auto
        {
            AutoID = 1,
            AutoBezeichnung = "Lamborghini",
            Beschreibung = "Dieses Auto ist ein Lambo",
            Leistung = 500,
            Farbe = "Schwarz",
            Inverkehrssetzung = DateTime.Today,
            Kilometerstand = 12000,
            Preis = 120000,
            Zustand = false,
        };

        Auto auto2 = new Auto
        {
            AutoID = 2,
            AutoBezeichnung = "Audi",
            Beschreibung = "Dieses Auto ist ein Audi",
            Leistung = 300,
            Farbe = "Schwarz",
            Inverkehrssetzung = DateTime.Today,
            Kilometerstand = 120200,
            Preis = 15000,
            Zustand = false,
        };


        private List<Auto> autoliste = new List<Auto>();




        public MainWindow()
        {
            autoliste.Add(auto);
            autoliste.Add(auto2);

            InitializeComponent();
            // Wichtig!
            this.DataContext = auto;

            auswahlListe.ItemsSource = autoliste;
            auswahlListe.CanUserAddRows = false;
            auswahlListe.CanUserSortColumns = true;
            auswahlListe.IsReadOnly = true;

            auswahlListe.SelectionMode = DataGridSelectionMode.Single;
            auswahlListe.SelectionMode = DataGridSelectionMode.Extended;

            delete.Click += new RoutedEventHandler(AuswahlListe_MouseDoubleClick);
        }

        private void AuswahlListe_MouseDoubleClick(object sender, RoutedEventArgs e)
        {
            if (auswahlListe.SelectedItem != null)
            {
                Auto auswahl = (Auto)auswahlListe.SelectedItem;
                MessageBox.Show("Ausgewähltes Auto: " + auswahl.AutoID + "\n" + auswahl.Beschreibung + "\n" + auswahl.AutoBezeichnung);
            }
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            Auto auto = new Auto
            {
                AutoBezeichnung = Bezeichnung.Text,
                Beschreibung = Beschreibung.Text,
                Leistung = Convert.ToInt64(Leistung.Text),
                Farbe = Farbe.Text,
                Inverkehrssetzung = Convert.ToDateTime(Inverkehr.Text),
                Kilometerstand = Convert.ToInt64(Kilometerstand.Text),
                Preis = Convert.ToInt64(Preis.Text),
                Zustand = Convert.ToBoolean(Zustand.Text),
            };
        }
    }
}
