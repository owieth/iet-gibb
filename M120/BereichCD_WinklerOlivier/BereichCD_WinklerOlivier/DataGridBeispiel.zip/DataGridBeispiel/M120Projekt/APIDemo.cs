﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    static class APIDemo
    {
        #region KlasseA
        // Create
        public static void create()
        {
            Data.Auto auto = new Data.Auto();
            auto.Beschreibung = "erstes Auto";
            auto.AutoBezeichnung = "Audi";
            auto.Leistung = 400;
            auto.Farbe = "Gelb";
            auto.Inverkehrssetzung = DateTime.Today;
            auto.Kilometerstand = 3000;
            auto.Preis = 90000;
            auto.Zustand = true;
        }
        

        // Read
        //public static Auto getAutoById(long id)
        //{
        //}
        // Update
        public static void update()
        {

        }
        // Delete
        public static void delete()
        { 
        }
        #endregion
    }
}
