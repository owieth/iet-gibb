﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    class Auto
    {
        public Int64 AutoID { get; set; }
        public String Beschreibung { get; set; }
        public String AutoBezeichnung { get; set; }
        public Int64 Leistung { get; set; }
        public String Farbe { get; set; }
        public Int64 Kilometerstand { get; set; }
        public DateTime Inverkehrssetzung { get; set; }
        public Boolean Zustand { get; set; }
        public Int64 Preis { get; set; }
    }
}
