﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace M120Projekt.Data
{
    public class Auto
    {
        #region Datenbankschicht
        [Key]
        public Int64 AutoID { get; set; }
        [Required]
        public String Beschreibung { get; set; }
        [Required]
        public String AutoBezeichnung { get; set; }
        [Required]
        public Int64 Leistung { get; set; }
        [Required]
        public String Farbe { get; set; }
        [Required]
        public Int64 Kilometerstand { get; set; }
        [Required]
        public DateTime Inverkehrssetzung { get; set; }
        [Required]
        public Boolean Zustand { get; set; }
        [Required]
        public Int64 Preis { get; set; }
        #endregion
        #region Applikationsschicht
        public Auto() { }
        [NotMapped]
        public String BerechnetesAttribut
        {
            get
            {
                return "Im Getter kann Code eingefügt werden für berechnete Attribute";
            }
        }
        public static IEnumerable<Data.Auto> LesenAlle()
        {
            return (from record in Data.Global.context.KlasseA select record);
        }
        //public static Data.Auto LesenID(Int64 klasseAId)
        //{
        //    return (from record in Data.Global.context.KlasseA where record.AutoID == AutoID select record).FirstOrDefault();
        //}
        public Int64 Erstellen()
        {
            Data.Global.context.KlasseA.Add(this);
            Data.Global.context.SaveChanges();
            return this.AutoID;
        }
        public Int64 Aktualisieren()
        {
            Data.Global.context.Entry(this).State = System.Data.Entity.EntityState.Modified;
            Data.Global.context.SaveChanges();
            return this.AutoID;
        }
        public void Loeschen()
        {
            Data.Global.context.Entry(this).State = System.Data.Entity.EntityState.Deleted;
            Data.Global.context.SaveChanges();
        }
        public override string ToString()
        {
            return AutoID.ToString(); // Für bessere Coded UI Test Erkennung
        }
        #endregion
    }
}
