﻿namespace MaterialDesignThemes.Wpf
{
    public delegate void DialogClosingEventHandler(object sender, DialogClosingEventArgs eventArgs);
}