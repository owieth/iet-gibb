﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    public class DatenAuto
    {
        public String Autobezeichnung { get; set; }
        public Int32 Leistung { get; set; }
        public String Farbe { get; set; }
        public Int32 Baujahr { get; set; }
        public Int32 Inverkehrssetzung { get; set; }
        public bool Neuwertig { get; set; }
        public Int32 Preis { get; set; }
        public String Bezeichnung { get; set; }
    }
}
